#include <ros/ros.h>
#include<leasmo/LeasMo.h>

int main(int argc, char **argv)
{
    ros::init(argc, argv, "lesmo");
    LeasMo lm;
    ros::spin();
    return 0;
}