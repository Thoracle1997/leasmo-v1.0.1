#include "likelihoodMap.h"

LikelihoodMap::LikelihoodMap() {
}
LikelihoodMap::~LikelihoodMap() {
}

LikelihoodMap::LikelihoodMap(const nav_msgs::OccupancyGridConstPtr &msg, double max_dist, double sigma) {
    max_occ_dist_ = max_dist;
    sigma_ = sigma;
    occ_msg2prob_map(msg);
}

void LikelihoodMap::prob_map2occ_msg(nav_msgs::OccupancyGrid &msg) {
    msg.info.width = size_x_;
    msg.info.height = size_y_;
    msg.info.resolution = resolution_;
    msg.info.origin.position.x = origin_x_;
    msg.info.origin.position.y = origin_y_;
    msg.info.origin.position.z = 0;
    msg.info.origin.orientation.w = 0;
    msg.info.origin.orientation.x = 0;
    msg.info.origin.orientation.y = 0;
    msg.info.origin.orientation.z = 0;

    msg.data.resize(size_x_ * size_y_, -1);

    for (int i = 0; i < size_x_; i++) {
        for (int j = 0; j < size_y_; j++) {
            int x = static_cast<int>(gaussian_[i][j] * 100);
            msg.data[i + size_x_ * j] = x;
        }
    }
}

void LikelihoodMap::occ_msg2prob_map(const nav_msgs::OccupancyGridConstPtr &msg) {
    size_x_ = msg->info.width;
    size_y_ = msg->info.height;
    resolution_ = msg->info.resolution;
    origin_x_ = msg->info.origin.position.x;
    origin_y_ = msg->info.origin.position.y;

    occ_state_.resize(size_x_, vector<int>(size_y_, -1));
    gaussian_.resize(size_x_, vector<double>(size_y_, 0.0001));

    int temp_x, temp_y, num_cells;
    num_cells = size_x_ * size_y_;
    /*
    y
    |
    |____x
    */
    for (int i = 0; i < num_cells; i++) {
        //! x和y有问题
        temp_y = i / size_x_;
        temp_x = i % size_x_;

        if (msg->data[i] == 0) {
            occ_state_[temp_x][temp_y] = 0;
            //occ_state_[temp_x][temp_y] = -1;
            // 100% occupied
        } else if (msg->data[i] == 100) {
            occ_state_[temp_x][temp_y] = +1;
        } else {
            // free
            occ_state_[temp_x][temp_y] = 0;
        }
    }

    update_cspace();
}

void LikelihoodMap::enqueue(int i, int j,
                            int src_i, int src_j,
                            deque< shared_ptr<Cell> > &Q) {
    //? skip if initialized?  better if add all values up.
    if (!isValid(i, j) || gaussian_[i][j] > 0.1) {
        return;
    }
    // TODO: store a dist map to speed up.
    unsigned int di = abs(i - src_i);
    unsigned int dj = abs(j - src_j);
    double dist = sqrt(di * di + dj * dj);

    double dist_in_meter = dist*resolution_;
    if ( dist_in_meter > max_occ_dist_ ) {
        return;
    }
    double const_value = 1/ (sqrt(2*M_PI)*sigma_);
    gaussian_[i][j] = const_value * exp(- dist_in_meter * dist_in_meter / (2 * sigma_ * sigma_));

    shared_ptr<Cell> cell(new Cell(i, j, src_i, src_j));
    Q.push_back(cell);

}

void LikelihoodMap::update_cspace() {
    // priority queue is not necessary
    std::deque< std::shared_ptr<Cell> > Q;

    for (int i = 0; i < size_x_; i++) {
        for (int j = 0; j < size_y_; j++) {

            if (occ_state_[i][j] == 1) {
                gaussian_[i][j] = 1.0;
                std::shared_ptr<Cell> cell(new Cell(i, j, i, j));
                Q.push_back(cell);
            }
        }
    }

    while (!Q.empty()) {
        std::shared_ptr<Cell> c = Q.front();
        Q.pop_front();
        enqueue(c->i_ - 1, c->j_, c->src_i_, c->src_j_, Q);
        enqueue(c->i_ + 1, c->j_, c->src_i_, c->src_j_, Q);
        enqueue(c->i_, c->j_ - 1, c->src_i_, c->src_j_, Q);
        enqueue(c->i_, c->j_ + 1, c->src_i_, c->src_j_, Q);
    }


}

bool LikelihoodMap::isValid(int grid_x, int grid_y) {
    return grid_x > 0 && grid_y > 0 && grid_x < size_x_ - 1 && grid_y < size_y_ - 1;
}

bool LikelihoodMap::isValid(double world_x, double world_y) {
    double max_x = size_x_ * resolution_ + origin_x_;
    double max_y = size_y_ * resolution_ + origin_y_;
    return world_x > origin_x_ && world_y > origin_y_ && world_x < max_x && world_y < max_y;
}

bool LikelihoodMap::grid2World(int grid_x, int grid_y, double &world_x, double &world_y) {
    if (isValid(grid_x, grid_y)) {
        world_x = origin_x_ + grid_x * resolution_;
        world_y = origin_y_ + grid_y * resolution_;
    } else {
        return false;
    }
    return true;
}

bool LikelihoodMap::world2Grid(double world_x, double world_y, int &grid_x, int &grid_y) {
    if (isValid(world_x, world_y)) {
        grid_x = floor((world_x - origin_x_) / resolution_);
        grid_y = floor((world_y - origin_y_) / resolution_);
    } else {
        return false;
    }
    return true;
}

bool LikelihoodMap::world2Grid(double world_x, double world_y, double &grid_x, double &grid_y) {
    if (isValid(world_x, world_y)) {
        grid_x = (world_x - origin_x_) / resolution_;
        grid_y = (world_y - origin_y_) / resolution_;
    } else {
        return false;
    }
    return true;
}
