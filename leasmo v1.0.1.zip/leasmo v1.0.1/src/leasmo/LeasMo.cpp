#include<LeasMo.h>

LeasMo::LeasMo() 
{
    ros::NodeHandle private_nh_("~");
    private_nh_.param("scan_topic", p_scan_topic_, std::string("scan"));
    private_nh_.param("scan_subscriber_queue_size", p_scan_subscriber_queue_size_, 10);
    private_nh_.param("base_frame", p_base_frame_, std::string("laser_link"));
    private_nh_.param("map_frame", p_map_frame_, std::string("map"));
    private_nh_.param("output_timing", p_timing_output_,true);
    private_nh_.param("iteration", iteration_,10);
    private_nh_.param("LivMer_u_init", LivMer_u_init_, 0.1f);
    scanSubscriber_ = node_.subscribe(p_scan_topic_, p_scan_subscriber_queue_size_, &LeasMo::scanCallback, this); //订阅激光
    mapSubscriber_= node_.subscribe(p_map_frame_, 1, &LeasMo::mapReceived, this); //订阅地图
    scan_point_cloud_publisher_ = node_.advertise<sensor_msgs::PointCloud>("leasmo_cloud",1,false); //发布匹配点云
    is_map_received_ = false;
}

LeasMo::~LeasMo()
{

}

void LeasMo::scanCallback(const sensor_msgs::LaserScan& scan) //订阅到激光后开始和地图匹配
{
   ros::WallTime start_time = ros::WallTime::now();    
   const ros::Duration dur(0.5);
   tf::StampedTransform laser_transform;

//获得base和laser的tf

  if (tf_.waitForTransform(p_base_frame_, scan.header.frame_id, scan.header.stamp, dur)) 
    {
      tf_.lookupTransform(p_base_frame_, scan.header.frame_id, scan.header.stamp, laser_transform);
    }
    else
    {
      ROS_INFO("lookupTransform %s to %s timed out. Could not transform laser scan into base_frame.", p_base_frame_.c_str(), scan.header.frame_id.c_str());
      return;
    }
    
    // 激光转点云
    projector_.projectLaser(scan, laser_point_cloud_, 30.0);

  //获得base相对map的位姿，为方便转换，这里base使用的laser_link
      Eigen::Vector3f start_estimate(Eigen::Vector3f::Zero());
      try
      {
        tf::StampedTransform stamped_pose;
        tf_.waitForTransform(p_map_frame_, p_base_frame_, scan.header.stamp, ros::Duration(0.5));
        tf_.lookupTransform(p_map_frame_, p_base_frame_,  scan.header.stamp, stamped_pose);
        const double yaw = tf::getYaw(stamped_pose.getRotation());
        start_estimate = Eigen::Vector3f(stamped_pose.getOrigin().getX(), stamped_pose.getOrigin().getY(), yaw);
      
                    Eigen::Vector3f test_estimate = start_estimate; 
                    if(is_map_received_)
                    {

                          Eigen::Vector3f delta_pose(PoseEstimate(start_estimate,GridMap,laser_point_cloud_)); //第一次运算用以得到初值
                           start_estimate += delta_pose;
                           sum_funVal_old = sum_funVal;
                           LivMer_u = 0.1;
                           LivMer_v = 2;

                          //根据测试经验可调整迭代次数,原始设定10
                          for(int i=0;i<iteration_;i++){
                                    Eigen::Vector3f delta_pose(PoseEstimate(start_estimate,GridMap,laser_point_cloud_));
                                    start_estimate += delta_pose;
                                    
                                    //std::cout << "\ndelta_pose\n" << delta_pose  << "\n"<<i<<"\n";//测试一：起始位姿，终止位姿，步进位姿，请搜索所有相关注释
                                    //std::cout << "\nCost = \n" << sum_funVal  << "  when   i="<<i<<" u= "<<LivMer_u<<" v= "<<LivMer_v<<"\n"; //测试二：每一次迭代的Cost，请搜索所有相关注释

                                    }
                          //std::cout << "\nstart_estimate\n" << test_estimate  << "\n";//测试一用
                          //std::cout << "\nend_estimate\n" << start_estimate  << "\n";//测试一用
                                      Eigen::Vector3f delta_estimate = start_estimate - test_estimate;
                                      laser_point_cloud_new_ = MatchedLaserPoint(delta_estimate,laser_point_cloud_);
                                      //scan_point_cloud_publisher_.publish(laser_point_cloud_);
                                      scan_point_cloud_publisher_.publish(laser_point_cloud_new_); //发布匹配点云
                          //发布新tf用，start_estimate为最终的base(这里是laser_link)到map的位姿
                          //delta_estimate为位姿更新量
                         // tf::Transform new_estimate (tf::createQuaternionFromYaw(start_estimate[2]),tf::Vector3(start_estimate[0],start_estimate[1],0));
                         // br_.sendTransform( tf::StampedTransform(new_estimate, scan.header.stamp, p_map_frame_, "test_frame_"));//p_base_frame_
                    }else{
                      ROS_INFO("No Map Received!");
                      return;
                    }
      }
      catch(tf::TransformException e)
      {
        ROS_ERROR("Transform from %s to %s failed\n", p_map_frame_.c_str(), p_base_frame_.c_str());
      }
      if (p_timing_output_)
      {
        ros::WallDuration duration = ros::WallTime::now() - start_time;
        ROS_INFO("Least Square Matching took: %f milliseconds", duration.toSec()*1000.0f );//计时
      }
}

 void LeasMo::mapReceived(const nav_msgs::OccupancyGridConstPtr& msg) //订阅地图
{
    LikelihoodMap Likelihood_(msg,0.15,0.05); 
    Likelihood_.prob_map2occ_msg(GridMap); //计算概率地图储存在GridMap中，概率范围为0-100

         ROS_INFO("Received a %d X %d map @ %.3f m/pix\n",
           GridMap.info.width,
           GridMap.info.height,
           GridMap.info.resolution);

    is_map_received_ = true;
}

//主要函数，得到位姿修正
Eigen::Vector3f LeasMo::PoseEstimate(Eigen::Vector3f& estimate,const nav_msgs::OccupancyGrid& GridMap,const sensor_msgs::PointCloud& dataPoints)
{
   int size = dataPoints.points.size();
   Eigen::Affine2f transform(getTransformForState(estimate));
    float sinRot = sin(estimate[2]);
    float cosRot = cos(estimate[2]);  
    Eigen::Matrix3f H = Eigen::Matrix3f::Zero();
    Eigen::Vector3f dTr = Eigen::Vector3f::Zero();

    sum_funVal = 0; //测试二用
                 for (int i = 0; i < size; ++i) {
                //转到地图坐标
                      const Eigen::Vector2f currPoint(dataPoints.points[i].x,dataPoints.points[i].y) ;
                      //输出雅可比矩阵(J1,J2,J3),此处有地图缩放
                      Eigen::Vector3f transformedPointData(interpMapValueWithDerivatives((transform * currPoint)/GridMap.info.resolution,GridMap));
                      float funVal = 1.5f - transformedPointData[0]; //与原版不同，这里（1-M）修改为（1.5-M），主要防止M>1，次要让系数倍率缩小
                      sum_funVal += funVal*funVal; //测试二用
                      //dTr 这个向量计算的是公式12 的求和符号后面的部分
                            dTr[0] += transformedPointData[1] * funVal;
                            dTr[1] += transformedPointData[2] * funVal;
                      /*
                      这个对应论文中公式 13，14 ,计算 M的梯度叉乘S对旋转角度的偏导数
                      */
                            float rotDeriv = ((-sinRot * currPoint.x() - cosRot * currPoint.y()) 
                                              * transformedPointData[1] + 
                                              (cosRot * currPoint.x() - sinRot * currPoint.y()) 
                                              * transformedPointData[2]);
                      
                            dTr[2] += rotDeriv * funVal;

                            H(0, 0) += transformedPointData[1]*transformedPointData[1];
                            H(1, 1) +=transformedPointData[2]*transformedPointData[2];
                            H(2, 2) += rotDeriv*rotDeriv;
                      
                            H(0, 1) += transformedPointData[1] * transformedPointData[2];
                            H(0, 2) += transformedPointData[1] * rotDeriv;
                            H(1, 2) += transformedPointData[2] * rotDeriv;
                  }
                  //黑森矩阵计算，因为是对称阵所以有三项可以直接复制
                  H(1, 0) = H(0, 1);
                  H(2, 0) = H(0, 2);
                  H(2, 1) = H(1, 2);

            //L-M中的阻尼系数
            H(0,0) += LivMer_u;
            H(1,1) += LivMer_u;
            H(2,2) += LivMer_u;

            //计算梯度下降结果 (H^-1)*dTr
           Eigen::Vector3f searchDir (H.inverse() * dTr);
           //L-M法
           float P = 2 * (sum_funVal_old - sum_funVal) / (LivMer_u*(searchDir[0]*searchDir[0]+searchDir[1]*searchDir[1]+searchDir[2]*searchDir[2]) + (searchDir[0] * dTr[0]+searchDir[1] * dTr[1]+searchDir[2] * dTr[2]));
           if (P>=0)
           {
                      LivMer_u =  LivMer_u * max(0.33f , 1-(2*P-1)*(2*P-1)*(2*P-1));
                      LivMer_v = 2;
                              // std::cout << "\nsearchdir\n" << searchDir  << "\n";测试三，观察结果
                              //这里限制平移步长小于1/2地图格，旋转步长小于2度
                              if(searchDir[0]>GridMap.info.resolution/2){
                                searchDir[0] = GridMap.info.resolution/2;
                              } else if(searchDir[0]<-GridMap.info.resolution/2){
                                searchDir[0] = -GridMap.info.resolution/2;
                              }

                              if(searchDir[1]>GridMap.info.resolution/2) {
                                searchDir[1] = GridMap.info.resolution/2;
                              } else if(searchDir[1]<-GridMap.info.resolution/2){
                                searchDir[1] = -GridMap.info.resolution/2;
                              }

                              if (searchDir[2] > 0.02f) {
                                searchDir[2] = 0.02f;
                              } else if (searchDir[2] < -0.02f) {
                                searchDir[2] = -0.02f;
                              }
                              sum_funVal_old = sum_funVal;
                              return searchDir;
           }
          else{
                     LivMer_u *= LivMer_v;
                     LivMer_v *=2;
            return  Eigen::Vector3f::Zero();
          }

}

//Vector3转Affine2
 Eigen::Affine2f LeasMo::getTransformForState(const Eigen::Vector3f& transVector)
  {
    return Eigen::Translation2f(transVector[0], transVector[1]) * Eigen::Rotation2Df(transVector[2]);
  }

//输出矩阵(M,dM/dx,dM/dy),M是概率值
Eigen::Vector3f LeasMo::interpMapValueWithDerivatives(const Eigen::Vector2f& coords,const nav_msgs::OccupancyGrid& GridMap)
  {
    //地图偏置
    int switch_x = GridMap.info.origin.position.x/GridMap.info.resolution;
    int switch_y = GridMap.info.origin.position.y/GridMap.info.resolution;

    //不要超出地图
     if( (coords[0] -switch_x< 0.0f) || (coords[0] -switch_x> GridMap.info.width) || (coords[1] -switch_y< 0.0f) || (coords[1] -switch_y>GridMap.info.height))
     {
       //ROS_INFO("Out of Map!");
        return Eigen::Vector3f(0.0f, 0.0f, 0.0f);
     }

    //用取整法得到小数坐标
    Eigen::Vector2i indMin(coords.cast<int>());
    Eigen::Vector2f factors(coords - indMin.cast<float>());

    int sizeX = GridMap.info.width;
    //得到该点的地图索引
    int index = (indMin[1] - switch_y) * sizeX + (indMin[0] - switch_x);
    //邻近四点赋值
      intensities[0] = GridMap.data[index]; 
       ++index;
      intensities[1] = GridMap.data[index]; 
      index += sizeX-1;
      intensities[2] = GridMap.data[index]; 
       ++index;
      intensities[3] = GridMap.data[index]; 
      //计算雅可比
      float dx1 = intensities[0] - intensities[1];
      float dx2 = intensities[2] - intensities[3];
      float dy1 = intensities[0] - intensities[2];
      float dy2 = intensities[1] - intensities[3];

      float xFacInv = (1.0f - factors[0]);
      float yFacInv = (1.0f - factors[1]);

      return Eigen::Vector3f(
      (((intensities[0] * xFacInv + intensities[1] * factors[0]) * (yFacInv)) +
      ((intensities[2] * xFacInv + intensities[3] * factors[0]) * (factors[1])))*0.01, //M，这里乘以系数0.01是因为概率地图取值0-100，与原版0-1不同
      -((dx1 * xFacInv) + (dx2 * factors[0])), //partial x
      -((dy1 * yFacInv) + (dy2 * factors[1])) //partial y
    );
  }

//点云转换到map坐标系
sensor_msgs::PointCloud  LeasMo::MatchedLaserPoint(Eigen::Vector3f& estimate,const sensor_msgs::PointCloud& dataPoints)
{
      sensor_msgs::PointCloud Laser = dataPoints;
      int size = dataPoints.points.size();
      Eigen::Affine2f transform(getTransformForState(estimate));

           for (int i = 0; i < size; ++i) {
                   const Eigen::Vector2f prevPoint(dataPoints.points[i].x,dataPoints.points[i].y) ;
                   const Eigen::Vector2f currPoint(transform* prevPoint);
                   Laser.points[i].x = currPoint[0];
                   Laser.points[i].y = currPoint[1];
           }
          return Laser;
}