#ifndef LIKELIHOODMAND_H_
#define LIKELIHOODMAND_H_

#include <cmath>
#include <memory>
#include <queue>
#include <deque>
#include <string>
#include <vector>

#include <ros/ros.h>

#include <nav_msgs/OccupancyGrid.h>

using namespace std;

class Cell {
public:
    unsigned int i_, j_;
    unsigned int src_i_, src_j_;
    //double gauss_value_;
    Cell(unsigned int i, unsigned int j, unsigned int src_i, unsigned int src_j)
        : i_(i),
          j_(j),
          src_i_(src_i),
          src_j_(src_j)
    {
    }
};

class LikelihoodMap {
public:
    LikelihoodMap(const nav_msgs::OccupancyGridConstPtr &msgPtr, double max_dist, double simga);
    LikelihoodMap();
    ~LikelihoodMap();
    // update likelihood value based on occ_state.
    void occ_msg2prob_map(const nav_msgs::OccupancyGridConstPtr &msg); 
    void prob_map2occ_msg(nav_msgs::OccupancyGrid &msg);
    void update_cspace();
    void enqueue(int i, int j,
                 int src_i, int src_j,
                 deque< shared_ptr<Cell> > &Q);
    bool isValid(int grid_x, int grid_y);
    bool isValid(double world_x, double world_y);
    bool grid2World(int grid_x, int grid_y, double &world_x, double &world_y);
    bool world2Grid(double world_x, double world_y, int &grid_x, int &grid_y);
    bool world2Grid(double world_x, double world_y, double &grid_x, double &grid_y);
    // left down corner of the map in world coordinate frame
    double origin_x_, origin_y_;
    // Map dimensions (number of cells)
    int size_x_, size_y_;
    // Map resolution (m/cell)
    double resolution_;
    // Max distance at which we care about obstacles, for constructing likelihood field
    // Unit: meters
    double max_occ_dist_;
    // sigma of gaussian distribution
    double sigma_;
    //  The map data, in row-major order, starting with (0,0).
    vector< vector<int> > occ_state_;
    vector< vector<double> > gaussian_;
};

#endif
