#ifndef LEASMO_H__
#define LEASMO_H__

#include <ros/ros.h>
#include <sensor_msgs/PointCloud.h>
#include <sensor_msgs/LaserScan.h>
#include <std_msgs/String.h>
#include "tf/transform_listener.h"
#include "tf/transform_broadcaster.h"
#include "tf/message_filter.h"
#include "laser_geometry/laser_geometry.h"
#include "nav_msgs/GetMap.h"
#include "nav_msgs/SetMap.h"
#include <Eigen/Geometry>
#include <Eigen/LU>
#include "likelihoodMap.h"

class LeasMo
{
public:
  LeasMo();
  ~LeasMo();

void scanCallback(const sensor_msgs::LaserScan& scan);
void mapReceived(const nav_msgs::OccupancyGridConstPtr& msg);

protected:
ros::NodeHandle node_;
ros::Publisher scan_point_cloud_publisher_; //点云发布
ros::Subscriber scanSubscriber_; //激光订阅
ros::Subscriber mapSubscriber_;//地图订阅 
sensor_msgs::PointCloud laser_point_cloud_;
sensor_msgs::PointCloud laser_point_cloud_new_;
laser_geometry::LaserProjection projector_; 
nav_msgs::OccupancyGrid  GridMap;
Eigen::Vector4f intensities;//某点周围的四像素
tf::TransformListener tf_;
tf::TransformBroadcaster br_;
//初始参数
std::string p_scan_topic_;
std::string p_base_frame_;
std::string p_map_frame_;
int p_scan_subscriber_queue_size_;
int iteration_;
bool p_timing_output_;
bool is_map_received_;
float sum_funVal;
float sum_funVal_old;
float LivMer_u;
float LivMer_u_init_;
float LivMer_v;

private:
Eigen::Vector3f PoseEstimate(Eigen::Vector3f& estimate,const nav_msgs::OccupancyGrid& GridMap,const sensor_msgs::PointCloud& dataPoints);
Eigen::Affine2f getTransformForState(const Eigen::Vector3f& transVector) ;
Eigen::Vector3f interpMapValueWithDerivatives(const Eigen::Vector2f& coords,const nav_msgs::OccupancyGrid& GridMap);
sensor_msgs::PointCloud MatchedLaserPoint(Eigen::Vector3f& estimate,const sensor_msgs::PointCloud& dataPoints);

};

#endif
